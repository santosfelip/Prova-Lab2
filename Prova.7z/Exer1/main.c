#include <stdio.h>
#include <stdlib.h>
#include "main.h"

int main()
{
    Aluno ***mat = NULL;
    int N=2,M=2;
    int i,j;


    mat = CriarMatriz(N,M);

    for(i=0;i<N;i++){
        for(j=0;j<M;j++){
            mat[i][j] = Cadastro();
        }
    }

    Imprime(mat,N,M);

    Limpa(mat,N);

    return 0;
}
Aluno ***CriarMatriz(int N, int M)
{
    Aluno ***mat = malloc(N*sizeof(Aluno **));
    int i;
    for(i=0;i<N; i++){
        mat[i] = malloc(M*sizeof(Aluno*));
    }

    return mat;
}

Aluno *Cadastro()
{
    Aluno *academico;
    academico = malloc(sizeof(Aluno*));
    Liberar(academico);

    printf("Digite os Dados do Aluno: \n");
    //preencher os dados do ponteiro dadosP
    printf("Nome: ");
    scanf("%s",academico->dadosP->nome);
    printf("Endereco: ");
    scanf("%s",academico->dadosP->endereco);
    printf("RG: ");
    scanf("%d",&academico->dadosP->RG);

    //preencher os dados do ponteiro dadosC
    printf("ID do Curso: ");
    scanf("%d",&academico->dadosC->idCurso);
    printf("Curso: ");
    scanf("%s",academico->dadosC->curso);
    printf("Turma: ");
    scanf("%s",academico->dadosC->turma);

    //preencher os dados da Struct Aluno
    printf("RGA: ");
    scanf("%d",&academico->rga);

    //colocando aluno ativo
    academico->ativo = 1;

    return academico;

}
void Liberar(Aluno *academico)
{
    //Alocando posi��o para os elementos da struct
    academico->dadosP = malloc(sizeof(DadosPessoais));
    academico->dadosC = malloc(sizeof(DadosCurso));

    //Alocando posi��o para os elementos filhos de dadosP
    academico->dadosP->nome = malloc(sizeof(char)*20);
    academico->dadosP->endereco = malloc(sizeof(char)*50);

    //Alocando posi��o para os elementos filhos de dadosC
    academico->dadosC->curso = malloc(sizeof(char)*20);
    academico->dadosC->turma = malloc(sizeof(char)*20);

}
 void Imprime(Aluno ***mat, int N, int M)
 {
    int i,j;
    setbuf(stdin,NULL);
    char l='a';
    printf("Digite a letra: ");
    Imprime_Recursivo(mat,N-1,M-1,l,0);
    Nome(mat,N,M);

 }

void Imprime_Recursivo(Aluno ***mat, int N, int M,char letra, int j)
{
    if (N>=0)
    {
        if (j<=M)
        {
            if(conta(letra, mat[N][j]->dadosP->nome)==3)
            {
                printf("%s", mat[N][j]->dadosP->nome);
                printf("\n");
            }
            Imprime_Recursivo(mat,N,M,letra,j+1);
        }
       Imprime_Recursivo(mat,N-1,M,letra,j);
    }
}
int conta(char c, char *s){
    int i;
    int n = 0;

    for(i=0; s[i] != '\0';i++){
    if(s[i] == c)
        n = n+1;
    }
    return n;
}
void Nome(Aluno ***mat,int N, int M)
{
    int i,j;
    int id,linha;
    printf("Digite o ID: ");
    scanf("%d",&id);
    printf("Digite o ano: ");
    scanf("%d",&linha);

        for(j=0;j<M;j++,mat++){
            if(mat[linha][j]->dadosC->idCurso==id){
                printf("%s ",mat[linha][j]->dadosP->nome);
            }
        }
}

void Limpa(Aluno ***mat,int N)
{
    int i;
    for (i=0;i<N;i++)
    {
        free(mat[i]);
    }
    free(mat);
}
