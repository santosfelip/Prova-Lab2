#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

typedef struct dados1{
    char *nome;
    char *endereco;
    long RG
}DadosPessoais;

typedef struct dados2{
    int idCurso;
    char *curso;
    char *turma;
}DadosCurso;

typedef struct aluno{
    int rga;
    int ativo;
    DadosPessoais *dadosP;
    DadosCurso *dadosC;
}Aluno;

void Liberar(Aluno *academico);
Aluno ***CriarMatriz(int N, int M);
Aluno *Cadastro( );
void Imprime(Aluno ***mat, int N, int M);
void Imprime_Recursivo(Aluno ***mat, int N, int M,char letra,int j);
int conta(char c, char *s);
void Nome(Aluno ***mat,int N, int M);
void Limpa(Aluno ***mat,int N);

#endif // MAIN_H_INCLUDED
